/********************************************************************************
** Form generated from reading UI file 'interfata.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INTERFATA_H
#define UI_INTERFATA_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_sunt
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QFrame *Top_Bar_Frame;
    QHBoxLayout *horizontalLayout;
    QFrame *toggle_menu;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *toggle_BTN;
    QFrame *topBar;
    QHBoxLayout *horizontalLayout_4;
    QFrame *menu_options;
    QFrame *properties;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *minimizeButon;
    QPushButton *fullscreenBTN;
    QPushButton *closeBTN;
    QFrame *Content;
    QHBoxLayout *horizontalLayout_2;
    QFrame *leftMenu;
    QVBoxLayout *verticalLayout_2;
    QFrame *topMenu;
    QVBoxLayout *verticalLayout_3;
    QPushButton *homeButton;
    QPushButton *infoButton;
    QPushButton *SaveButton;
    QPushButton *workspace_BTN;
    QFrame *settingFrame;
    QVBoxLayout *verticalLayout_4;
    QPushButton *settings;
    QFrame *pages;
    QVBoxLayout *verticalLayout_5;
    QStackedWidget *Pages;
    QWidget *homePage;
    QHBoxLayout *horizontalLayout_9;
    QFrame *logoHomePage;
    QHBoxLayout *horizontalLayout_10;
    QLabel *label_2;
    QFrame *buttonHomeFrame;
    QVBoxLayout *verticalLayout_6;
    QFrame *frame_4;
    QPushButton *newProject;
    QPushButton *exampleButton;
    QWidget *WorkSpace;
    QHBoxLayout *horizontalLayout_16;
    QFrame *objectItems;
    QVBoxLayout *verticalLayout_9;
    QFrame *itemsDrop;
    QHBoxLayout *horizontalLayout_17;
    QPushButton *dropDown;
    QLabel *titleDrop;
    QFrame *objectsUML;
    QGridLayout *gridLayout_2;
    QPushButton *implementationBTN;
    QPushButton *aggregationBTN;
    QPushButton *compositionBTN;
    QPushButton *classWithAttributesAndMethods;
    QPushButton *associationBTN;
    QPushButton *dependencyBTN;
    QPushButton *classWithAttributes;
    QPushButton *inheritanceBTN;
    QPushButton *confirmationButton;
    QFrame *drawSpace;
    QWidget *Settings;
    QHBoxLayout *horizontalLayout_11;
    QFrame *gridSettings4;
    QGridLayout *gridLayout;
    QFrame *Csetting;
    QFrame *Bsetting;
    QFrame *Dsetting;
    QVBoxLayout *verticalLayout_8;
    QPushButton *submitSettings;
    QFrame *Asetting;
    QVBoxLayout *verticalLayout_7;
    QFrame *settingName;
    QHBoxLayout *horizontalLayout_12;
    QFrame *resolutionIcon;
    QLabel *resolutionText;
    QFrame *width;
    QHBoxLayout *horizontalLayout_14;
    QFrame *widthIcon;
    QLineEdit *lineEdit;
    QLabel *pxWLabel;
    QFrame *frame_2;
    QHBoxLayout *horizontalLayout_13;
    QFrame *iconHeight;
    QLineEdit *lineEdit_2;
    QLabel *pxHLabel;
    QWidget *Informatii;
    QHBoxLayout *horizontalLayout_15;
    QFrame *informatiiLayOut;
    QGridLayout *gridLayout_3;
    QFrame *video1;
    QVBoxLayout *verticalLayout_10;
    QPushButton *playVideo1;
    QLabel *video1Description;
    QFrame *video2;
    QVBoxLayout *verticalLayout_11;
    QPushButton *playVideo2;
    QLabel *video2Description;
    QFrame *video3;
    QVBoxLayout *verticalLayout_12;
    QPushButton *playVideo2_2;
    QLabel *video2Description_2;
    QFrame *video4;
    QVBoxLayout *verticalLayout_13;
    QPushButton *playVideo2_3;
    QLabel *video2Description_3;
    QWidget *exampleOfUse;
    QGridLayout *gridLayout_4;
    QFrame *imageExample1;
    QVBoxLayout *verticalLayout_14;
    QLabel *img1;
    QLabel *step1;
    QFrame *imageExample2;
    QVBoxLayout *verticalLayout_15;
    QLabel *img2;
    QLabel *step2;
    QFrame *imageExample4;
    QVBoxLayout *verticalLayout_17;
    QLabel *img4;
    QLabel *step4;
    QFrame *imageExample5;
    QVBoxLayout *verticalLayout_18;
    QLabel *img5;
    QLabel *step5;
    QFrame *imageExample3;
    QVBoxLayout *verticalLayout_16;
    QLabel *img3;
    QLabel *step3;
    QFrame *imageExample6;
    QVBoxLayout *verticalLayout_19;
    QLabel *img6;
    QLabel *step6;
    QFrame *imageExample8;
    QVBoxLayout *verticalLayout_21;
    QLabel *img8;
    QLabel *step8;
    QFrame *imageExample7;
    QVBoxLayout *verticalLayout_20;
    QLabel *img7;
    QLabel *step7;
    QFrame *StatusBar;
    QHBoxLayout *horizontalLayout_6;
    QFrame *statusBar;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label;
    QFrame *size_grab;
    QHBoxLayout *horizontalLayout_8;

    void setupUi(QMainWindow *sunt)
    {
        if (sunt->objectName().isEmpty())
            sunt->setObjectName(QString::fromUtf8("sunt"));
        sunt->resize(1280, 831);
        sunt->setMinimumSize(QSize(1280, 720));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/imagini/resources/3d-modeling (3).png"), QSize(), QIcon::Normal, QIcon::Off);
        sunt->setWindowIcon(icon);
        centralwidget = new QWidget(sunt);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        Top_Bar_Frame = new QFrame(centralwidget);
        Top_Bar_Frame->setObjectName(QString::fromUtf8("Top_Bar_Frame"));
        Top_Bar_Frame->setMinimumSize(QSize(0, 40));
        Top_Bar_Frame->setMaximumSize(QSize(16777215, 40));
        Top_Bar_Frame->setStyleSheet(QString::fromUtf8("background-color: rgb(35, 35, 35);"));
        Top_Bar_Frame->setFrameShape(QFrame::NoFrame);
        Top_Bar_Frame->setFrameShadow(QFrame::Raised);
        horizontalLayout = new QHBoxLayout(Top_Bar_Frame);
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        toggle_menu = new QFrame(Top_Bar_Frame);
        toggle_menu->setObjectName(QString::fromUtf8("toggle_menu"));
        toggle_menu->setMinimumSize(QSize(0, 40));
        toggle_menu->setMaximumSize(QSize(70, 40));
        toggle_menu->setStyleSheet(QString::fromUtf8("background-color: rgb(25, 25, 25);"));
        toggle_menu->setFrameShape(QFrame::NoFrame);
        toggle_menu->setFrameShadow(QFrame::Raised);
        horizontalLayout_3 = new QHBoxLayout(toggle_menu);
        horizontalLayout_3->setSpacing(0);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        toggle_BTN = new QPushButton(toggle_menu);
        toggle_BTN->setObjectName(QString::fromUtf8("toggle_BTN"));
        toggle_BTN->setMinimumSize(QSize(0, 40));
        toggle_BTN->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180);\n"
"}"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/imagini/resources/output-onlinepngtools.png"), QSize(), QIcon::Normal, QIcon::Off);
        toggle_BTN->setIcon(icon1);
        toggle_BTN->setIconSize(QSize(25, 25));
        toggle_BTN->setCheckable(true);
        toggle_BTN->setFlat(true);

        horizontalLayout_3->addWidget(toggle_BTN);


        horizontalLayout->addWidget(toggle_menu);

        topBar = new QFrame(Top_Bar_Frame);
        topBar->setObjectName(QString::fromUtf8("topBar"));
        topBar->setMinimumSize(QSize(0, 40));
        topBar->setMaximumSize(QSize(16777215, 40));
        topBar->setFrameShape(QFrame::NoFrame);
        topBar->setFrameShadow(QFrame::Raised);
        horizontalLayout_4 = new QHBoxLayout(topBar);
        horizontalLayout_4->setSpacing(0);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        menu_options = new QFrame(topBar);
        menu_options->setObjectName(QString::fromUtf8("menu_options"));
        menu_options->setMinimumSize(QSize(0, 40));
        menu_options->setMaximumSize(QSize(16777215, 40));
        menu_options->setFrameShape(QFrame::NoFrame);
        menu_options->setFrameShadow(QFrame::Raised);

        horizontalLayout_4->addWidget(menu_options);

        properties = new QFrame(topBar);
        properties->setObjectName(QString::fromUtf8("properties"));
        properties->setMinimumSize(QSize(0, 40));
        properties->setMaximumSize(QSize(90, 40));
        properties->setFrameShape(QFrame::NoFrame);
        properties->setFrameShadow(QFrame::Raised);
        horizontalLayout_5 = new QHBoxLayout(properties);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 3, 0);
        minimizeButon = new QPushButton(properties);
        minimizeButon->setObjectName(QString::fromUtf8("minimizeButon"));
        minimizeButon->setMinimumSize(QSize(30, 40));
        minimizeButon->setMaximumSize(QSize(30, 40));
        minimizeButon->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180)\n"
"}"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/imagini/resources/output-onlinepngtools (6).png"), QSize(), QIcon::Normal, QIcon::Off);
        minimizeButon->setIcon(icon2);
        minimizeButon->setFlat(true);

        horizontalLayout_5->addWidget(minimizeButon, 0, Qt::AlignHCenter|Qt::AlignVCenter);

        fullscreenBTN = new QPushButton(properties);
        fullscreenBTN->setObjectName(QString::fromUtf8("fullscreenBTN"));
        fullscreenBTN->setMinimumSize(QSize(30, 40));
        fullscreenBTN->setMaximumSize(QSize(30, 40));
        fullscreenBTN->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180)\n"
"}"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/imagini/resources/output-onlinepngtools (7).png"), QSize(), QIcon::Normal, QIcon::Off);
        fullscreenBTN->setIcon(icon3);
        fullscreenBTN->setFlat(true);

        horizontalLayout_5->addWidget(fullscreenBTN, 0, Qt::AlignHCenter|Qt::AlignVCenter);

        closeBTN = new QPushButton(properties);
        closeBTN->setObjectName(QString::fromUtf8("closeBTN"));
        closeBTN->setMinimumSize(QSize(30, 40));
        closeBTN->setMaximumSize(QSize(30, 40));
        closeBTN->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180)\n"
"}"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/imagini/resources/output-onlinepngtools (5).png"), QSize(), QIcon::Normal, QIcon::Off);
        closeBTN->setIcon(icon4);
        closeBTN->setFlat(true);

        horizontalLayout_5->addWidget(closeBTN, 0, Qt::AlignHCenter|Qt::AlignVCenter);


        horizontalLayout_4->addWidget(properties, 0, Qt::AlignRight);


        horizontalLayout->addWidget(topBar);


        verticalLayout->addWidget(Top_Bar_Frame);

        Content = new QFrame(centralwidget);
        Content->setObjectName(QString::fromUtf8("Content"));
        Content->setMaximumSize(QSize(16777215, 16777215));
        Content->setStyleSheet(QString::fromUtf8("background-color: rgb(45, 45, 45);"));
        Content->setFrameShape(QFrame::NoFrame);
        Content->setFrameShadow(QFrame::Raised);
        horizontalLayout_2 = new QHBoxLayout(Content);
        horizontalLayout_2->setSpacing(0);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        leftMenu = new QFrame(Content);
        leftMenu->setObjectName(QString::fromUtf8("leftMenu"));
        leftMenu->setMinimumSize(QSize(70, 0));
        leftMenu->setMaximumSize(QSize(70, 16777215));
        leftMenu->setStyleSheet(QString::fromUtf8("background-color : rgb(35,35,35);"));
        leftMenu->setFrameShape(QFrame::NoFrame);
        leftMenu->setFrameShadow(QFrame::Raised);
        verticalLayout_2 = new QVBoxLayout(leftMenu);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        topMenu = new QFrame(leftMenu);
        topMenu->setObjectName(QString::fromUtf8("topMenu"));
        topMenu->setFrameShape(QFrame::NoFrame);
        topMenu->setFrameShadow(QFrame::Raised);
        verticalLayout_3 = new QVBoxLayout(topMenu);
        verticalLayout_3->setSpacing(0);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        homeButton = new QPushButton(topMenu);
        homeButton->setObjectName(QString::fromUtf8("homeButton"));
        homeButton->setMinimumSize(QSize(0, 40));
        homeButton->setMaximumSize(QSize(16777215, 40));
        homeButton->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180)\n"
"}"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/imagini/resources/output-onlinepngtools (2).png"), QSize(), QIcon::Normal, QIcon::Off);
        homeButton->setIcon(icon5);
        homeButton->setIconSize(QSize(25, 25));
        homeButton->setCheckable(true);
        homeButton->setFlat(true);

        verticalLayout_3->addWidget(homeButton);

        infoButton = new QPushButton(topMenu);
        infoButton->setObjectName(QString::fromUtf8("infoButton"));
        infoButton->setMinimumSize(QSize(0, 40));
        infoButton->setMaximumSize(QSize(16777215, 40));
        infoButton->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180)\n"
"}"));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/imagini/resources/informatii.png"), QSize(), QIcon::Normal, QIcon::Off);
        infoButton->setIcon(icon6);
        infoButton->setIconSize(QSize(25, 25));
        infoButton->setFlat(true);

        verticalLayout_3->addWidget(infoButton);

        SaveButton = new QPushButton(topMenu);
        SaveButton->setObjectName(QString::fromUtf8("SaveButton"));
        SaveButton->setMinimumSize(QSize(0, 40));
        SaveButton->setMaximumSize(QSize(16777215, 40));
        SaveButton->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180)\n"
"}"));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/imagini/resources/save_all.png"), QSize(), QIcon::Normal, QIcon::Off);
        SaveButton->setIcon(icon7);
        SaveButton->setIconSize(QSize(25, 25));
        SaveButton->setFlat(true);

        verticalLayout_3->addWidget(SaveButton);

        workspace_BTN = new QPushButton(topMenu);
        workspace_BTN->setObjectName(QString::fromUtf8("workspace_BTN"));
        workspace_BTN->setMinimumSize(QSize(0, 40));
        workspace_BTN->setMaximumSize(QSize(16777215, 40));
        workspace_BTN->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180)\n"
"}"));
        QIcon icon8;
        icon8.addFile(QString::fromUtf8(":/imagini/resources/workspace.png"), QSize(), QIcon::Normal, QIcon::Off);
        workspace_BTN->setIcon(icon8);
        workspace_BTN->setIconSize(QSize(25, 25));
        workspace_BTN->setFlat(true);

        verticalLayout_3->addWidget(workspace_BTN);


        verticalLayout_2->addWidget(topMenu, 0, Qt::AlignTop);

        settingFrame = new QFrame(leftMenu);
        settingFrame->setObjectName(QString::fromUtf8("settingFrame"));
        settingFrame->setMaximumSize(QSize(16777215, 40));
        settingFrame->setFrameShape(QFrame::NoFrame);
        settingFrame->setFrameShadow(QFrame::Raised);
        verticalLayout_4 = new QVBoxLayout(settingFrame);
        verticalLayout_4->setSpacing(0);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        settings = new QPushButton(settingFrame);
        settings->setObjectName(QString::fromUtf8("settings"));
        settings->setMinimumSize(QSize(0, 40));
        settings->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180)\n"
"}"));
        QIcon icon9;
        icon9.addFile(QString::fromUtf8(":/imagini/resources/output-onlinepngtools (3).png"), QSize(), QIcon::Normal, QIcon::Off);
        settings->setIcon(icon9);
        settings->setIconSize(QSize(25, 25));
        settings->setFlat(true);

        verticalLayout_4->addWidget(settings);


        verticalLayout_2->addWidget(settingFrame);


        horizontalLayout_2->addWidget(leftMenu);

        pages = new QFrame(Content);
        pages->setObjectName(QString::fromUtf8("pages"));
        pages->setFrameShape(QFrame::NoFrame);
        pages->setFrameShadow(QFrame::Raised);
        verticalLayout_5 = new QVBoxLayout(pages);
        verticalLayout_5->setSpacing(0);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        Pages = new QStackedWidget(pages);
        Pages->setObjectName(QString::fromUtf8("Pages"));
        homePage = new QWidget();
        homePage->setObjectName(QString::fromUtf8("homePage"));
        horizontalLayout_9 = new QHBoxLayout(homePage);
        horizontalLayout_9->setSpacing(0);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        horizontalLayout_9->setContentsMargins(0, 0, 0, 0);
        logoHomePage = new QFrame(homePage);
        logoHomePage->setObjectName(QString::fromUtf8("logoHomePage"));
        logoHomePage->setFrameShape(QFrame::NoFrame);
        logoHomePage->setFrameShadow(QFrame::Raised);
        horizontalLayout_10 = new QHBoxLayout(logoHomePage);
        horizontalLayout_10->setSpacing(0);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        horizontalLayout_10->setContentsMargins(50, 50, 50, 50);
        label_2 = new QLabel(logoHomePage);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setPixmap(QPixmap(QString::fromUtf8(":/imagini/resources/dasdasd.png")));
        label_2->setScaledContents(true);
        label_2->setAlignment(Qt::AlignCenter);

        horizontalLayout_10->addWidget(label_2);


        horizontalLayout_9->addWidget(logoHomePage);

        buttonHomeFrame = new QFrame(homePage);
        buttonHomeFrame->setObjectName(QString::fromUtf8("buttonHomeFrame"));
        buttonHomeFrame->setMinimumSize(QSize(250, 0));
        buttonHomeFrame->setMaximumSize(QSize(250, 16777215));
        buttonHomeFrame->setFrameShape(QFrame::NoFrame);
        verticalLayout_6 = new QVBoxLayout(buttonHomeFrame);
        verticalLayout_6->setSpacing(20);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(50, 0, 50, 40);
        frame_4 = new QFrame(buttonHomeFrame);
        frame_4->setObjectName(QString::fromUtf8("frame_4"));
        frame_4->setMinimumSize(QSize(250, 0));
        frame_4->setMaximumSize(QSize(250, 16777215));
        frame_4->setFrameShape(QFrame::NoFrame);
        frame_4->setFrameShadow(QFrame::Raised);

        verticalLayout_6->addWidget(frame_4);

        newProject = new QPushButton(buttonHomeFrame);
        newProject->setObjectName(QString::fromUtf8("newProject"));
        newProject->setMinimumSize(QSize(150, 50));
        newProject->setMaximumSize(QSize(150, 50));
        newProject->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(68, 68, 68);\n"
"border-radius: 15px;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180)\n"
"}\n"
""));
        QIcon icon10;
        icon10.addFile(QString::fromUtf8(":/imagini/resources/new_file.png"), QSize(), QIcon::Normal, QIcon::Off);
        newProject->setIcon(icon10);
        newProject->setIconSize(QSize(30, 30));
        newProject->setFlat(true);

        verticalLayout_6->addWidget(newProject);

        exampleButton = new QPushButton(buttonHomeFrame);
        exampleButton->setObjectName(QString::fromUtf8("exampleButton"));
        exampleButton->setMinimumSize(QSize(150, 50));
        exampleButton->setMaximumSize(QSize(150, 50));
        exampleButton->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(68, 68, 68);\n"
"border-radius: 15px;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180)\n"
"}\n"
""));
        QIcon icon11;
        icon11.addFile(QString::fromUtf8(":/imagini/resources/example_research.png"), QSize(), QIcon::Normal, QIcon::Off);
        exampleButton->setIcon(icon11);
        exampleButton->setIconSize(QSize(30, 30));
        exampleButton->setFlat(true);

        verticalLayout_6->addWidget(exampleButton);


        horizontalLayout_9->addWidget(buttonHomeFrame);

        Pages->addWidget(homePage);
        WorkSpace = new QWidget();
        WorkSpace->setObjectName(QString::fromUtf8("WorkSpace"));
        horizontalLayout_16 = new QHBoxLayout(WorkSpace);
        horizontalLayout_16->setSpacing(0);
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));
        horizontalLayout_16->setContentsMargins(0, 0, 0, 0);
        objectItems = new QFrame(WorkSpace);
        objectItems->setObjectName(QString::fromUtf8("objectItems"));
        objectItems->setMinimumSize(QSize(250, 0));
        objectItems->setMaximumSize(QSize(250, 16777215));
        objectItems->setFrameShape(QFrame::NoFrame);
        verticalLayout_9 = new QVBoxLayout(objectItems);
        verticalLayout_9->setSpacing(0);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        verticalLayout_9->setContentsMargins(0, 0, 0, 0);
        itemsDrop = new QFrame(objectItems);
        itemsDrop->setObjectName(QString::fromUtf8("itemsDrop"));
        itemsDrop->setMinimumSize(QSize(0, 40));
        itemsDrop->setMaximumSize(QSize(16777215, 40));
        itemsDrop->setStyleSheet(QString::fromUtf8("QFrame{\n"
"background-color: rgb(30, 30, 30);\n"
"}"));
        itemsDrop->setFrameShape(QFrame::NoFrame);
        itemsDrop->setFrameShadow(QFrame::Raised);
        horizontalLayout_17 = new QHBoxLayout(itemsDrop);
        horizontalLayout_17->setSpacing(0);
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        horizontalLayout_17->setContentsMargins(0, 0, 0, 0);
        dropDown = new QPushButton(itemsDrop);
        dropDown->setObjectName(QString::fromUtf8("dropDown"));
        dropDown->setMinimumSize(QSize(40, 40));
        dropDown->setMaximumSize(QSize(40, 40));
        dropDown->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"background-color: rgb(30, 30, 30);\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180)\n"
"}"));
        QIcon icon12;
        icon12.addFile(QString::fromUtf8(":/imagini/resources/restoremenu.png"), QSize(), QIcon::Normal, QIcon::Off);
        icon12.addFile(QString::fromUtf8(":/imagini/resources/dropdown.png"), QSize(), QIcon::Normal, QIcon::On);
        dropDown->setIcon(icon12);
        dropDown->setIconSize(QSize(25, 25));
        dropDown->setCheckable(true);
        dropDown->setFlat(true);

        horizontalLayout_17->addWidget(dropDown);

        titleDrop = new QLabel(itemsDrop);
        titleDrop->setObjectName(QString::fromUtf8("titleDrop"));
        QFont font;
        font.setPointSize(15);
        titleDrop->setFont(font);
        titleDrop->setStyleSheet(QString::fromUtf8("QLabel{color: rgb(255, 255, 255);\n"
"}\n"
""));
        titleDrop->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        horizontalLayout_17->addWidget(titleDrop);


        verticalLayout_9->addWidget(itemsDrop, 0, Qt::AlignTop);

        objectsUML = new QFrame(objectItems);
        objectsUML->setObjectName(QString::fromUtf8("objectsUML"));
        objectsUML->setMinimumSize(QSize(0, 450));
        objectsUML->setStyleSheet(QString::fromUtf8("border: 2px solid rgb(35, 35, 35);"));
        objectsUML->setFrameShape(QFrame::NoFrame);
        objectsUML->setFrameShadow(QFrame::Plain);
        gridLayout_2 = new QGridLayout(objectsUML);
        gridLayout_2->setSpacing(0);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        implementationBTN = new QPushButton(objectsUML);
        implementationBTN->setObjectName(QString::fromUtf8("implementationBTN"));
        implementationBTN->setMinimumSize(QSize(80, 40));
        implementationBTN->setMaximumSize(QSize(80, 40));
        implementationBTN->setStyleSheet(QString::fromUtf8("\n"
"QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180);\n"
"border-radius: 2px;\n"
"}\n"
"\n"
"QToolTip{\n"
"border: 0px soild;\n"
"color: #ffffff;\n"
"}"));
        QIcon icon13;
        icon13.addFile(QString::fromUtf8(":/imagini/resources/implementation.png"), QSize(), QIcon::Normal, QIcon::Off);
        implementationBTN->setIcon(icon13);
        implementationBTN->setIconSize(QSize(80, 40));
        implementationBTN->setFlat(true);

        gridLayout_2->addWidget(implementationBTN, 1, 0, 1, 1);

        aggregationBTN = new QPushButton(objectsUML);
        aggregationBTN->setObjectName(QString::fromUtf8("aggregationBTN"));
        aggregationBTN->setMinimumSize(QSize(80, 40));
        aggregationBTN->setMaximumSize(QSize(80, 40));
        aggregationBTN->setStyleSheet(QString::fromUtf8("\n"
"QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180);\n"
"border-radius: 2px;\n"
"}\n"
"\n"
"QToolTip{\n"
"border: 0px soild;\n"
"color: #ffffff;\n"
"}"));
        QIcon icon14;
        icon14.addFile(QString::fromUtf8(":/imagini/resources/aggregation.png"), QSize(), QIcon::Normal, QIcon::Off);
        aggregationBTN->setIcon(icon14);
        aggregationBTN->setIconSize(QSize(80, 40));
        aggregationBTN->setFlat(true);

        gridLayout_2->addWidget(aggregationBTN, 2, 0, 1, 1);

        compositionBTN = new QPushButton(objectsUML);
        compositionBTN->setObjectName(QString::fromUtf8("compositionBTN"));
        compositionBTN->setMinimumSize(QSize(80, 40));
        compositionBTN->setMaximumSize(QSize(80, 40));
        compositionBTN->setStyleSheet(QString::fromUtf8("\n"
"QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180);\n"
"border-radius: 2px;\n"
"}\n"
"\n"
"QToolTip{\n"
"border: 0px soild;\n"
"color: #ffffff;\n"
"}"));
        QIcon icon15;
        icon15.addFile(QString::fromUtf8(":/imagini/resources/composition.png"), QSize(), QIcon::Normal, QIcon::Off);
        compositionBTN->setIcon(icon15);
        compositionBTN->setIconSize(QSize(80, 40));
        compositionBTN->setFlat(true);

        gridLayout_2->addWidget(compositionBTN, 2, 1, 1, 1);

        classWithAttributesAndMethods = new QPushButton(objectsUML);
        classWithAttributesAndMethods->setObjectName(QString::fromUtf8("classWithAttributesAndMethods"));
        classWithAttributesAndMethods->setMinimumSize(QSize(80, 40));
        classWithAttributesAndMethods->setMaximumSize(QSize(80, 40));
        classWithAttributesAndMethods->setStyleSheet(QString::fromUtf8("\n"
"QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180);\n"
"border-radius: 2px;\n"
"}\n"
"\n"
"QToolTip{\n"
"border: 0px soild;\n"
"color: #ffffff;\n"
"}"));
        QIcon icon16;
        icon16.addFile(QString::fromUtf8(":/imagini/resources/class.png"), QSize(), QIcon::Normal, QIcon::Off);
        classWithAttributesAndMethods->setIcon(icon16);
        classWithAttributesAndMethods->setIconSize(QSize(80, 40));
        classWithAttributesAndMethods->setFlat(true);

        gridLayout_2->addWidget(classWithAttributesAndMethods, 3, 1, 1, 1);

        associationBTN = new QPushButton(objectsUML);
        associationBTN->setObjectName(QString::fromUtf8("associationBTN"));
        associationBTN->setMinimumSize(QSize(80, 40));
        associationBTN->setMaximumSize(QSize(80, 40));
        associationBTN->setStyleSheet(QString::fromUtf8("\n"
"QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180);\n"
"border-radius: 2px;\n"
"}\n"
"\n"
"QToolTip{\n"
"border: 0px soild;\n"
"color: #ffffff;\n"
"}"));
        QIcon icon17;
        icon17.addFile(QString::fromUtf8(":/imagini/resources/Association.png"), QSize(), QIcon::Normal, QIcon::Off);
        associationBTN->setIcon(icon17);
        associationBTN->setIconSize(QSize(80, 40));
        associationBTN->setFlat(true);

        gridLayout_2->addWidget(associationBTN, 0, 0, 1, 1);

        dependencyBTN = new QPushButton(objectsUML);
        dependencyBTN->setObjectName(QString::fromUtf8("dependencyBTN"));
        dependencyBTN->setMinimumSize(QSize(80, 40));
        dependencyBTN->setMaximumSize(QSize(80, 40));
        dependencyBTN->setStyleSheet(QString::fromUtf8("\n"
"QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180);\n"
"border-radius: 2px;\n"
"}\n"
"\n"
"QToolTip{\n"
"border: 0px soild;\n"
"color: #ffffff;\n"
"}"));
        QIcon icon18;
        icon18.addFile(QString::fromUtf8(":/imagini/resources/dependency.png"), QSize(), QIcon::Normal, QIcon::Off);
        dependencyBTN->setIcon(icon18);
        dependencyBTN->setIconSize(QSize(80, 40));
        dependencyBTN->setFlat(true);

        gridLayout_2->addWidget(dependencyBTN, 1, 1, 1, 1);

        classWithAttributes = new QPushButton(objectsUML);
        classWithAttributes->setObjectName(QString::fromUtf8("classWithAttributes"));
        classWithAttributes->setMinimumSize(QSize(80, 40));
        classWithAttributes->setMaximumSize(QSize(80, 40));
        classWithAttributes->setStyleSheet(QString::fromUtf8("\n"
"QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180);\n"
"border-radius: 2px;\n"
"}\n"
"\n"
"QToolTip{\n"
"border: 0px soild;\n"
"color: #ffffff;\n"
"}"));
        QIcon icon19;
        icon19.addFile(QString::fromUtf8(":/imagini/resources/class2.png"), QSize(), QIcon::Normal, QIcon::Off);
        classWithAttributes->setIcon(icon19);
        classWithAttributes->setIconSize(QSize(80, 70));
        classWithAttributes->setFlat(true);

        gridLayout_2->addWidget(classWithAttributes, 3, 0, 1, 1);

        inheritanceBTN = new QPushButton(objectsUML);
        inheritanceBTN->setObjectName(QString::fromUtf8("inheritanceBTN"));
        inheritanceBTN->setMinimumSize(QSize(80, 40));
        inheritanceBTN->setMaximumSize(QSize(80, 40));
        inheritanceBTN->setStyleSheet(QString::fromUtf8("\n"
"QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180);\n"
"border-radius: 2px;\n"
"}\n"
"\n"
"QToolTip{\n"
"border: 0px soild;\n"
"color: #ffffff;\n"
"}"));
        QIcon icon20;
        icon20.addFile(QString::fromUtf8(":/imagini/resources/inheritance.png"), QSize(), QIcon::Normal, QIcon::Off);
        inheritanceBTN->setIcon(icon20);
        inheritanceBTN->setIconSize(QSize(80, 40));
        inheritanceBTN->setFlat(true);

        gridLayout_2->addWidget(inheritanceBTN, 0, 1, 1, 1);


        verticalLayout_9->addWidget(objectsUML);

        confirmationButton = new QPushButton(objectItems);
        confirmationButton->setObjectName(QString::fromUtf8("confirmationButton"));
        confirmationButton->setMinimumSize(QSize(120, 40));
        confirmationButton->setMaximumSize(QSize(120, 120));
        QFont font1;
        font1.setPointSize(10);
        confirmationButton->setFont(font1);
        confirmationButton->setStyleSheet(QString::fromUtf8("\n"
"QPushButton{\n"
"color : #FFFFFF;\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180);\n"
"border-radius: 2px;\n"
"}\n"
"\n"
"QToolTip{\n"
"border: 0px soild;\n"
"color: #ffffff;\n"
"}"));
        confirmationButton->setFlat(true);

        verticalLayout_9->addWidget(confirmationButton, 0, Qt::AlignHCenter);


        horizontalLayout_16->addWidget(objectItems, 0, Qt::AlignTop);

        drawSpace = new QFrame(WorkSpace);
        drawSpace->setObjectName(QString::fromUtf8("drawSpace"));
        drawSpace->setFrameShape(QFrame::NoFrame);
        drawSpace->setFrameShadow(QFrame::Plain);

        horizontalLayout_16->addWidget(drawSpace);

        Pages->addWidget(WorkSpace);
        Settings = new QWidget();
        Settings->setObjectName(QString::fromUtf8("Settings"));
        horizontalLayout_11 = new QHBoxLayout(Settings);
        horizontalLayout_11->setSpacing(0);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        horizontalLayout_11->setContentsMargins(0, 0, 0, 0);
        gridSettings4 = new QFrame(Settings);
        gridSettings4->setObjectName(QString::fromUtf8("gridSettings4"));
        gridSettings4->setFrameShape(QFrame::StyledPanel);
        gridSettings4->setFrameShadow(QFrame::Raised);
        gridLayout = new QGridLayout(gridSettings4);
        gridLayout->setSpacing(0);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        Csetting = new QFrame(gridSettings4);
        Csetting->setObjectName(QString::fromUtf8("Csetting"));
        Csetting->setFrameShape(QFrame::StyledPanel);
        Csetting->setFrameShadow(QFrame::Raised);

        gridLayout->addWidget(Csetting, 1, 0, 1, 1);

        Bsetting = new QFrame(gridSettings4);
        Bsetting->setObjectName(QString::fromUtf8("Bsetting"));
        Bsetting->setFrameShape(QFrame::StyledPanel);
        Bsetting->setFrameShadow(QFrame::Raised);

        gridLayout->addWidget(Bsetting, 0, 1, 1, 1);

        Dsetting = new QFrame(gridSettings4);
        Dsetting->setObjectName(QString::fromUtf8("Dsetting"));
        Dsetting->setFrameShape(QFrame::StyledPanel);
        Dsetting->setFrameShadow(QFrame::Raised);
        verticalLayout_8 = new QVBoxLayout(Dsetting);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        submitSettings = new QPushButton(Dsetting);
        submitSettings->setObjectName(QString::fromUtf8("submitSettings"));
        submitSettings->setMinimumSize(QSize(90, 35));
        submitSettings->setMaximumSize(QSize(90, 35));
        submitSettings->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(68, 68, 68);\n"
"border-radius: 15px;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180)\n"
"}\n"
""));

        verticalLayout_8->addWidget(submitSettings);


        gridLayout->addWidget(Dsetting, 1, 1, 1, 1, Qt::AlignRight|Qt::AlignBottom);

        Asetting = new QFrame(gridSettings4);
        Asetting->setObjectName(QString::fromUtf8("Asetting"));
        Asetting->setFrameShape(QFrame::NoFrame);
        Asetting->setFrameShadow(QFrame::Raised);
        verticalLayout_7 = new QVBoxLayout(Asetting);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        settingName = new QFrame(Asetting);
        settingName->setObjectName(QString::fromUtf8("settingName"));
        settingName->setFrameShape(QFrame::StyledPanel);
        settingName->setFrameShadow(QFrame::Raised);
        horizontalLayout_12 = new QHBoxLayout(settingName);
        horizontalLayout_12->setSpacing(10);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        horizontalLayout_12->setContentsMargins(0, 0, 0, 0);
        resolutionIcon = new QFrame(settingName);
        resolutionIcon->setObjectName(QString::fromUtf8("resolutionIcon"));
        resolutionIcon->setMinimumSize(QSize(40, 40));
        resolutionIcon->setMaximumSize(QSize(40, 40));
        resolutionIcon->setStyleSheet(QString::fromUtf8("image: url(:/imagini/resources/resolution (2).png) 0 0 0 0 stretch stretch;"));
        resolutionIcon->setFrameShape(QFrame::NoFrame);
        resolutionIcon->setFrameShadow(QFrame::Raised);

        horizontalLayout_12->addWidget(resolutionIcon);

        resolutionText = new QLabel(settingName);
        resolutionText->setObjectName(QString::fromUtf8("resolutionText"));
        resolutionText->setMinimumSize(QSize(200, 40));
        resolutionText->setMaximumSize(QSize(200, 40));
        resolutionText->setFont(font);
        resolutionText->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        resolutionText->setFrameShape(QFrame::NoFrame);
        resolutionText->setScaledContents(true);

        horizontalLayout_12->addWidget(resolutionText);


        verticalLayout_7->addWidget(settingName, 0, Qt::AlignHCenter);

        width = new QFrame(Asetting);
        width->setObjectName(QString::fromUtf8("width"));
        width->setFrameShape(QFrame::StyledPanel);
        width->setFrameShadow(QFrame::Raised);
        horizontalLayout_14 = new QHBoxLayout(width);
        horizontalLayout_14->setSpacing(10);
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        horizontalLayout_14->setContentsMargins(0, 0, 0, 0);
        widthIcon = new QFrame(width);
        widthIcon->setObjectName(QString::fromUtf8("widthIcon"));
        widthIcon->setMinimumSize(QSize(40, 40));
        widthIcon->setMaximumSize(QSize(40, 40));
        widthIcon->setStyleSheet(QString::fromUtf8("image: url(:/imagini/resources/widthj.png) 0 0 0 0 stretch stretch;"));
        widthIcon->setFrameShape(QFrame::NoFrame);
        widthIcon->setFrameShadow(QFrame::Raised);

        horizontalLayout_14->addWidget(widthIcon);

        lineEdit = new QLineEdit(width);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setMinimumSize(QSize(250, 40));
        lineEdit->setMaximumSize(QSize(250, 40));
        QFont font2;
        font2.setPointSize(16);
        lineEdit->setFont(font2);
        lineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(235, 235, 235);\n"
"border: 0px solid;\n"
"border-radius: 15px;\n"
"\n"
""));

        horizontalLayout_14->addWidget(lineEdit);

        pxWLabel = new QLabel(width);
        pxWLabel->setObjectName(QString::fromUtf8("pxWLabel"));
        pxWLabel->setMinimumSize(QSize(40, 40));
        pxWLabel->setMaximumSize(QSize(40, 40));
        pxWLabel->setFont(font2);
        pxWLabel->setStyleSheet(QString::fromUtf8("color: #ffffff\n"
""));
        pxWLabel->setAlignment(Qt::AlignCenter);

        horizontalLayout_14->addWidget(pxWLabel);


        verticalLayout_7->addWidget(width, 0, Qt::AlignHCenter);

        frame_2 = new QFrame(Asetting);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        horizontalLayout_13 = new QHBoxLayout(frame_2);
        horizontalLayout_13->setSpacing(10);
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        horizontalLayout_13->setContentsMargins(0, 0, 0, 0);
        iconHeight = new QFrame(frame_2);
        iconHeight->setObjectName(QString::fromUtf8("iconHeight"));
        iconHeight->setMinimumSize(QSize(40, 40));
        iconHeight->setMaximumSize(QSize(40, 40));
        iconHeight->setStyleSheet(QString::fromUtf8("image: url(:/imagini/resources/height.png) 0 0 0 0 stretch stretch;"));
        iconHeight->setFrameShape(QFrame::NoFrame);
        iconHeight->setFrameShadow(QFrame::Raised);

        horizontalLayout_13->addWidget(iconHeight);

        lineEdit_2 = new QLineEdit(frame_2);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setMinimumSize(QSize(250, 40));
        lineEdit_2->setMaximumSize(QSize(250, 40));
        lineEdit_2->setFont(font2);
        lineEdit_2->setStyleSheet(QString::fromUtf8("background-color: rgb(235, 235, 235);\n"
"border: 0px solid;\n"
"border-radius: 15px;\n"
"\n"
""));

        horizontalLayout_13->addWidget(lineEdit_2);

        pxHLabel = new QLabel(frame_2);
        pxHLabel->setObjectName(QString::fromUtf8("pxHLabel"));
        pxHLabel->setMinimumSize(QSize(40, 40));
        pxHLabel->setMaximumSize(QSize(40, 40));
        pxHLabel->setFont(font2);
        pxHLabel->setStyleSheet(QString::fromUtf8("color: #ffffff\n"
""));
        pxHLabel->setAlignment(Qt::AlignCenter);

        horizontalLayout_13->addWidget(pxHLabel);


        verticalLayout_7->addWidget(frame_2, 0, Qt::AlignHCenter);


        gridLayout->addWidget(Asetting, 0, 0, 1, 1);


        horizontalLayout_11->addWidget(gridSettings4);

        Pages->addWidget(Settings);
        Informatii = new QWidget();
        Informatii->setObjectName(QString::fromUtf8("Informatii"));
        horizontalLayout_15 = new QHBoxLayout(Informatii);
        horizontalLayout_15->setSpacing(0);
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        horizontalLayout_15->setContentsMargins(0, 0, 0, 0);
        informatiiLayOut = new QFrame(Informatii);
        informatiiLayOut->setObjectName(QString::fromUtf8("informatiiLayOut"));
        informatiiLayOut->setFrameShape(QFrame::NoFrame);
        informatiiLayOut->setFrameShadow(QFrame::Raised);
        gridLayout_3 = new QGridLayout(informatiiLayOut);
        gridLayout_3->setSpacing(0);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        video1 = new QFrame(informatiiLayOut);
        video1->setObjectName(QString::fromUtf8("video1"));
        video1->setFrameShape(QFrame::NoFrame);
        video1->setFrameShadow(QFrame::Raised);
        verticalLayout_10 = new QVBoxLayout(video1);
        verticalLayout_10->setSpacing(4);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        verticalLayout_10->setContentsMargins(4, 4, 4, 4);
        playVideo1 = new QPushButton(video1);
        playVideo1->setObjectName(QString::fromUtf8("playVideo1"));
        playVideo1->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"}"));
        QIcon icon21;
        icon21.addFile(QString::fromUtf8(":/imagini/resources/offVideo1.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        playVideo1->setIcon(icon21);
        playVideo1->setIconSize(QSize(600, 337));
        playVideo1->setCheckable(true);
        playVideo1->setFlat(true);

        verticalLayout_10->addWidget(playVideo1);

        video1Description = new QLabel(video1);
        video1Description->setObjectName(QString::fromUtf8("video1Description"));
        video1Description->setFont(font);
        video1Description->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        video1Description->setAlignment(Qt::AlignCenter);

        verticalLayout_10->addWidget(video1Description);


        gridLayout_3->addWidget(video1, 0, 0, 1, 1);

        video2 = new QFrame(informatiiLayOut);
        video2->setObjectName(QString::fromUtf8("video2"));
        video2->setFrameShape(QFrame::StyledPanel);
        video2->setFrameShadow(QFrame::Raised);
        verticalLayout_11 = new QVBoxLayout(video2);
        verticalLayout_11->setSpacing(4);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        verticalLayout_11->setContentsMargins(4, 4, 4, 4);
        playVideo2 = new QPushButton(video2);
        playVideo2->setObjectName(QString::fromUtf8("playVideo2"));
        playVideo2->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"}"));
        QIcon icon22;
        icon22.addFile(QString::fromUtf8(":/imagini/resources/onVideo2.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        playVideo2->setIcon(icon22);
        playVideo2->setIconSize(QSize(600, 337));
        playVideo2->setCheckable(true);
        playVideo2->setFlat(true);

        verticalLayout_11->addWidget(playVideo2);

        video2Description = new QLabel(video2);
        video2Description->setObjectName(QString::fromUtf8("video2Description"));
        video2Description->setFont(font);
        video2Description->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        video2Description->setAlignment(Qt::AlignCenter);

        verticalLayout_11->addWidget(video2Description);


        gridLayout_3->addWidget(video2, 0, 1, 1, 1);

        video3 = new QFrame(informatiiLayOut);
        video3->setObjectName(QString::fromUtf8("video3"));
        video3->setFrameShape(QFrame::StyledPanel);
        video3->setFrameShadow(QFrame::Raised);
        verticalLayout_12 = new QVBoxLayout(video3);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        playVideo2_2 = new QPushButton(video3);
        playVideo2_2->setObjectName(QString::fromUtf8("playVideo2_2"));
        playVideo2_2->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"}"));
        QIcon icon23;
        icon23.addFile(QString::fromUtf8(":/imagini/resources/600f3bd86887d-fbutube-maxresdefault (3).jpg"), QSize(), QIcon::Normal, QIcon::Off);
        playVideo2_2->setIcon(icon23);
        playVideo2_2->setIconSize(QSize(600, 337));
        playVideo2_2->setCheckable(true);
        playVideo2_2->setFlat(true);

        verticalLayout_12->addWidget(playVideo2_2);

        video2Description_2 = new QLabel(video3);
        video2Description_2->setObjectName(QString::fromUtf8("video2Description_2"));
        video2Description_2->setFont(font);
        video2Description_2->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        video2Description_2->setAlignment(Qt::AlignCenter);

        verticalLayout_12->addWidget(video2Description_2);


        gridLayout_3->addWidget(video3, 1, 0, 1, 1);

        video4 = new QFrame(informatiiLayOut);
        video4->setObjectName(QString::fromUtf8("video4"));
        video4->setFrameShape(QFrame::StyledPanel);
        video4->setFrameShadow(QFrame::Raised);
        verticalLayout_13 = new QVBoxLayout(video4);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        playVideo2_3 = new QPushButton(video4);
        playVideo2_3->setObjectName(QString::fromUtf8("playVideo2_3"));
        playVideo2_3->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"}"));
        QIcon icon24;
        icon24.addFile(QString::fromUtf8(":/imagini/resources/hqdefault.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        playVideo2_3->setIcon(icon24);
        playVideo2_3->setIconSize(QSize(600, 337));
        playVideo2_3->setCheckable(true);
        playVideo2_3->setFlat(true);

        verticalLayout_13->addWidget(playVideo2_3);

        video2Description_3 = new QLabel(video4);
        video2Description_3->setObjectName(QString::fromUtf8("video2Description_3"));
        video2Description_3->setFont(font);
        video2Description_3->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        video2Description_3->setAlignment(Qt::AlignCenter);

        verticalLayout_13->addWidget(video2Description_3);


        gridLayout_3->addWidget(video4, 1, 1, 1, 1);


        horizontalLayout_15->addWidget(informatiiLayOut);

        Pages->addWidget(Informatii);
        exampleOfUse = new QWidget();
        exampleOfUse->setObjectName(QString::fromUtf8("exampleOfUse"));
        gridLayout_4 = new QGridLayout(exampleOfUse);
        gridLayout_4->setSpacing(0);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setContentsMargins(0, 0, 0, 0);
        imageExample1 = new QFrame(exampleOfUse);
        imageExample1->setObjectName(QString::fromUtf8("imageExample1"));
        imageExample1->setMaximumSize(QSize(250, 250));
        imageExample1->setFrameShape(QFrame::NoFrame);
        imageExample1->setFrameShadow(QFrame::Raised);
        verticalLayout_14 = new QVBoxLayout(imageExample1);
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        img1 = new QLabel(imageExample1);
        img1->setObjectName(QString::fromUtf8("img1"));
        img1->setPixmap(QPixmap(QString::fromUtf8(":/imagini/resources/imageExample1.png")));
        img1->setScaledContents(true);
        img1->setAlignment(Qt::AlignCenter);

        verticalLayout_14->addWidget(img1);

        step1 = new QLabel(imageExample1);
        step1->setObjectName(QString::fromUtf8("step1"));
        step1->setMinimumSize(QSize(0, 40));
        step1->setMaximumSize(QSize(16777215, 40));
        QFont font3;
        font3.setPointSize(12);
        font3.setBold(true);
        font3.setWeight(75);
        step1->setFont(font3);
        step1->setStyleSheet(QString::fromUtf8("color: #FFFFFF"));
        step1->setAlignment(Qt::AlignCenter);

        verticalLayout_14->addWidget(step1);


        gridLayout_4->addWidget(imageExample1, 0, 0, 1, 1);

        imageExample2 = new QFrame(exampleOfUse);
        imageExample2->setObjectName(QString::fromUtf8("imageExample2"));
        imageExample2->setMaximumSize(QSize(250, 250));
        imageExample2->setFrameShape(QFrame::NoFrame);
        imageExample2->setFrameShadow(QFrame::Raised);
        verticalLayout_15 = new QVBoxLayout(imageExample2);
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        img2 = new QLabel(imageExample2);
        img2->setObjectName(QString::fromUtf8("img2"));
        img2->setMinimumSize(QSize(120, 0));
        img2->setMaximumSize(QSize(120, 16777215));
        img2->setPixmap(QPixmap(QString::fromUtf8(":/imagini/resources/imageExample2.png")));
        img2->setScaledContents(true);
        img2->setAlignment(Qt::AlignCenter);

        verticalLayout_15->addWidget(img2);

        step2 = new QLabel(imageExample2);
        step2->setObjectName(QString::fromUtf8("step2"));
        step2->setMinimumSize(QSize(0, 40));
        step2->setMaximumSize(QSize(16777215, 40));
        step2->setFont(font3);
        step2->setStyleSheet(QString::fromUtf8("color: #FFFFFF"));
        step2->setAlignment(Qt::AlignCenter);

        verticalLayout_15->addWidget(step2);


        gridLayout_4->addWidget(imageExample2, 0, 1, 1, 1);

        imageExample4 = new QFrame(exampleOfUse);
        imageExample4->setObjectName(QString::fromUtf8("imageExample4"));
        imageExample4->setMaximumSize(QSize(250, 250));
        imageExample4->setFrameShape(QFrame::NoFrame);
        imageExample4->setFrameShadow(QFrame::Raised);
        verticalLayout_17 = new QVBoxLayout(imageExample4);
        verticalLayout_17->setObjectName(QString::fromUtf8("verticalLayout_17"));
        img4 = new QLabel(imageExample4);
        img4->setObjectName(QString::fromUtf8("img4"));
        img4->setPixmap(QPixmap(QString::fromUtf8(":/imagini/resources/imageExample4.png")));
        img4->setScaledContents(true);
        img4->setAlignment(Qt::AlignCenter);

        verticalLayout_17->addWidget(img4);

        step4 = new QLabel(imageExample4);
        step4->setObjectName(QString::fromUtf8("step4"));
        step4->setMinimumSize(QSize(0, 40));
        step4->setMaximumSize(QSize(16777215, 40));
        step4->setFont(font3);
        step4->setStyleSheet(QString::fromUtf8("color: #FFFFFF"));
        step4->setAlignment(Qt::AlignCenter);

        verticalLayout_17->addWidget(step4);


        gridLayout_4->addWidget(imageExample4, 0, 3, 1, 1);

        imageExample5 = new QFrame(exampleOfUse);
        imageExample5->setObjectName(QString::fromUtf8("imageExample5"));
        imageExample5->setMaximumSize(QSize(250, 250));
        imageExample5->setFrameShape(QFrame::NoFrame);
        imageExample5->setFrameShadow(QFrame::Raised);
        verticalLayout_18 = new QVBoxLayout(imageExample5);
        verticalLayout_18->setObjectName(QString::fromUtf8("verticalLayout_18"));
        img5 = new QLabel(imageExample5);
        img5->setObjectName(QString::fromUtf8("img5"));
        img5->setPixmap(QPixmap(QString::fromUtf8(":/imagini/resources/drawContent.png")));
        img5->setScaledContents(true);
        img5->setAlignment(Qt::AlignCenter);

        verticalLayout_18->addWidget(img5);

        step5 = new QLabel(imageExample5);
        step5->setObjectName(QString::fromUtf8("step5"));
        step5->setMinimumSize(QSize(0, 40));
        step5->setMaximumSize(QSize(16777215, 40));
        step5->setFont(font3);
        step5->setStyleSheet(QString::fromUtf8("color: #FFFFFF"));
        step5->setAlignment(Qt::AlignCenter);

        verticalLayout_18->addWidget(step5);


        gridLayout_4->addWidget(imageExample5, 1, 0, 1, 1);

        imageExample3 = new QFrame(exampleOfUse);
        imageExample3->setObjectName(QString::fromUtf8("imageExample3"));
        imageExample3->setMaximumSize(QSize(250, 250));
        imageExample3->setFrameShape(QFrame::NoFrame);
        imageExample3->setFrameShadow(QFrame::Raised);
        verticalLayout_16 = new QVBoxLayout(imageExample3);
        verticalLayout_16->setObjectName(QString::fromUtf8("verticalLayout_16"));
        img3 = new QLabel(imageExample3);
        img3->setObjectName(QString::fromUtf8("img3"));
        img3->setPixmap(QPixmap(QString::fromUtf8(":/imagini/resources/imageExample3.png")));
        img3->setScaledContents(true);
        img3->setAlignment(Qt::AlignCenter);

        verticalLayout_16->addWidget(img3);

        step3 = new QLabel(imageExample3);
        step3->setObjectName(QString::fromUtf8("step3"));
        step3->setMinimumSize(QSize(0, 40));
        step3->setMaximumSize(QSize(16777215, 40));
        step3->setFont(font3);
        step3->setStyleSheet(QString::fromUtf8("color: #FFFFFF"));
        step3->setAlignment(Qt::AlignCenter);

        verticalLayout_16->addWidget(step3);


        gridLayout_4->addWidget(imageExample3, 0, 2, 1, 1);

        imageExample6 = new QFrame(exampleOfUse);
        imageExample6->setObjectName(QString::fromUtf8("imageExample6"));
        imageExample6->setMaximumSize(QSize(250, 250));
        imageExample6->setFrameShape(QFrame::NoFrame);
        imageExample6->setFrameShadow(QFrame::Raised);
        verticalLayout_19 = new QVBoxLayout(imageExample6);
        verticalLayout_19->setObjectName(QString::fromUtf8("verticalLayout_19"));
        img6 = new QLabel(imageExample6);
        img6->setObjectName(QString::fromUtf8("img6"));
        img6->setPixmap(QPixmap(QString::fromUtf8(":/imagini/resources/savecontent.png")));
        img6->setScaledContents(true);
        img6->setAlignment(Qt::AlignCenter);

        verticalLayout_19->addWidget(img6);

        step6 = new QLabel(imageExample6);
        step6->setObjectName(QString::fromUtf8("step6"));
        step6->setMinimumSize(QSize(0, 40));
        step6->setMaximumSize(QSize(16777215, 40));
        QFont font4;
        font4.setPointSize(13);
        font4.setBold(true);
        font4.setWeight(75);
        step6->setFont(font4);
        step6->setStyleSheet(QString::fromUtf8("color: #FFFFFF"));
        step6->setAlignment(Qt::AlignCenter);

        verticalLayout_19->addWidget(step6);


        gridLayout_4->addWidget(imageExample6, 1, 1, 1, 1);

        imageExample8 = new QFrame(exampleOfUse);
        imageExample8->setObjectName(QString::fromUtf8("imageExample8"));
        imageExample8->setMaximumSize(QSize(250, 250));
        imageExample8->setFrameShape(QFrame::NoFrame);
        imageExample8->setFrameShadow(QFrame::Raised);
        verticalLayout_21 = new QVBoxLayout(imageExample8);
        verticalLayout_21->setObjectName(QString::fromUtf8("verticalLayout_21"));
        img8 = new QLabel(imageExample8);
        img8->setObjectName(QString::fromUtf8("img8"));
        img8->setPixmap(QPixmap(QString::fromUtf8(":/imagini/resources/imageExample1.png")));
        img8->setScaledContents(true);
        img8->setAlignment(Qt::AlignCenter);

        verticalLayout_21->addWidget(img8);

        step8 = new QLabel(imageExample8);
        step8->setObjectName(QString::fromUtf8("step8"));
        step8->setMinimumSize(QSize(0, 40));
        step8->setMaximumSize(QSize(16777215, 40));
        step8->setFont(font3);
        step8->setStyleSheet(QString::fromUtf8("color: #FFFFFF"));
        step8->setAlignment(Qt::AlignCenter);

        verticalLayout_21->addWidget(step8);


        gridLayout_4->addWidget(imageExample8, 1, 3, 1, 1);

        imageExample7 = new QFrame(exampleOfUse);
        imageExample7->setObjectName(QString::fromUtf8("imageExample7"));
        imageExample7->setMaximumSize(QSize(250, 250));
        imageExample7->setFrameShape(QFrame::NoFrame);
        imageExample7->setFrameShadow(QFrame::Raised);
        verticalLayout_20 = new QVBoxLayout(imageExample7);
        verticalLayout_20->setObjectName(QString::fromUtf8("verticalLayout_20"));
        img7 = new QLabel(imageExample7);
        img7->setObjectName(QString::fromUtf8("img7"));
        img7->setPixmap(QPixmap(QString::fromUtf8(":/imagini/resources/viewCode.png")));
        img7->setScaledContents(true);
        img7->setAlignment(Qt::AlignCenter);

        verticalLayout_20->addWidget(img7);

        step7 = new QLabel(imageExample7);
        step7->setObjectName(QString::fromUtf8("step7"));
        step7->setMinimumSize(QSize(0, 40));
        step7->setMaximumSize(QSize(16777215, 40));
        step7->setFont(font3);
        step7->setStyleSheet(QString::fromUtf8("color: #FFFFFF"));
        step7->setAlignment(Qt::AlignCenter);

        verticalLayout_20->addWidget(step7);


        gridLayout_4->addWidget(imageExample7, 1, 2, 1, 1);

        Pages->addWidget(exampleOfUse);

        verticalLayout_5->addWidget(Pages);

        StatusBar = new QFrame(pages);
        StatusBar->setObjectName(QString::fromUtf8("StatusBar"));
        StatusBar->setMinimumSize(QSize(0, 20));
        StatusBar->setMaximumSize(QSize(16777215, 20));
        StatusBar->setStyleSheet(QString::fromUtf8("background-color : rgb(35,35,35);"));
        StatusBar->setFrameShape(QFrame::NoFrame);
        StatusBar->setFrameShadow(QFrame::Raised);
        horizontalLayout_6 = new QHBoxLayout(StatusBar);
        horizontalLayout_6->setSpacing(0);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        statusBar = new QFrame(StatusBar);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        statusBar->setMinimumSize(QSize(0, 20));
        statusBar->setMaximumSize(QSize(16777215, 20));
        statusBar->setFrameShape(QFrame::NoFrame);
        statusBar->setFrameShadow(QFrame::Raised);
        horizontalLayout_7 = new QHBoxLayout(statusBar);
        horizontalLayout_7->setSpacing(0);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(statusBar);
        label->setObjectName(QString::fromUtf8("label"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setMinimumSize(QSize(720, 20));
        label->setStyleSheet(QString::fromUtf8("color: rgb(113, 113, 113);"));

        horizontalLayout_7->addWidget(label);


        horizontalLayout_6->addWidget(statusBar, 0, Qt::AlignLeft|Qt::AlignTop);

        size_grab = new QFrame(StatusBar);
        size_grab->setObjectName(QString::fromUtf8("size_grab"));
        size_grab->setMinimumSize(QSize(20, 20));
        size_grab->setMaximumSize(QSize(20, 20));
        size_grab->setFrameShape(QFrame::NoFrame);
        size_grab->setFrameShadow(QFrame::Raised);
        horizontalLayout_8 = new QHBoxLayout(size_grab);
        horizontalLayout_8->setSpacing(0);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalLayout_8->setContentsMargins(0, 0, 0, 0);

        horizontalLayout_6->addWidget(size_grab, 0, Qt::AlignRight|Qt::AlignBottom);


        verticalLayout_5->addWidget(StatusBar);


        horizontalLayout_2->addWidget(pages);


        verticalLayout->addWidget(Content);

        sunt->setCentralWidget(centralwidget);

        retranslateUi(sunt);

        Pages->setCurrentIndex(4);


        QMetaObject::connectSlotsByName(sunt);
    } // setupUi

    void retranslateUi(QMainWindow *sunt)
    {
        sunt->setWindowTitle(QCoreApplication::translate("sunt", "MainWindow", nullptr));
        toggle_BTN->setText(QString());
        homeButton->setText(QString());
        infoButton->setText(QString());
        SaveButton->setText(QString());
        workspace_BTN->setText(QString());
        label_2->setText(QString());
        newProject->setText(QCoreApplication::translate("sunt", " New Project", nullptr));
        exampleButton->setText(QCoreApplication::translate("sunt", "Example", nullptr));
        dropDown->setText(QString());
        titleDrop->setText(QCoreApplication::translate("sunt", "UML ELEMENTS", nullptr));
#if QT_CONFIG(tooltip)
        implementationBTN->setToolTip(QCoreApplication::translate("sunt", "Implementation", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(statustip)
        implementationBTN->setStatusTip(QCoreApplication::translate("sunt", "Implementation", nullptr));
#endif // QT_CONFIG(statustip)
        implementationBTN->setText(QString());
#if QT_CONFIG(tooltip)
        aggregationBTN->setToolTip(QCoreApplication::translate("sunt", "Aggregation", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(statustip)
        aggregationBTN->setStatusTip(QCoreApplication::translate("sunt", "Aggregation", nullptr));
#endif // QT_CONFIG(statustip)
        aggregationBTN->setText(QString());
#if QT_CONFIG(tooltip)
        compositionBTN->setToolTip(QCoreApplication::translate("sunt", "Composition", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(statustip)
        compositionBTN->setStatusTip(QCoreApplication::translate("sunt", "Composition", nullptr));
#endif // QT_CONFIG(statustip)
        compositionBTN->setText(QString());
#if QT_CONFIG(tooltip)
        classWithAttributesAndMethods->setToolTip(QCoreApplication::translate("sunt", "Class With Attributes and Methods", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(statustip)
        classWithAttributesAndMethods->setStatusTip(QCoreApplication::translate("sunt", "Class With Attributes and Methods", nullptr));
#endif // QT_CONFIG(statustip)
        classWithAttributesAndMethods->setText(QString());
#if QT_CONFIG(tooltip)
        associationBTN->setToolTip(QCoreApplication::translate("sunt", "Association", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(statustip)
        associationBTN->setStatusTip(QCoreApplication::translate("sunt", "Association", nullptr));
#endif // QT_CONFIG(statustip)
        associationBTN->setText(QString());
#if QT_CONFIG(tooltip)
        dependencyBTN->setToolTip(QCoreApplication::translate("sunt", "Dependency", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(statustip)
        dependencyBTN->setStatusTip(QCoreApplication::translate("sunt", "Dependency", nullptr));
#endif // QT_CONFIG(statustip)
        dependencyBTN->setText(QString());
#if QT_CONFIG(tooltip)
        classWithAttributes->setToolTip(QCoreApplication::translate("sunt", "Class With Attributes", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(statustip)
        classWithAttributes->setStatusTip(QCoreApplication::translate("sunt", "Class With Attributes", nullptr));
#endif // QT_CONFIG(statustip)
        classWithAttributes->setText(QString());
#if QT_CONFIG(tooltip)
        inheritanceBTN->setToolTip(QCoreApplication::translate("sunt", "Inheritance", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(statustip)
        inheritanceBTN->setStatusTip(QCoreApplication::translate("sunt", "Inheritance", nullptr));
#endif // QT_CONFIG(statustip)
        inheritanceBTN->setText(QString());
        confirmationButton->setText(QCoreApplication::translate("sunt", "Confirm Drawing", nullptr));
        submitSettings->setText(QCoreApplication::translate("sunt", "Save Settings", nullptr));
        resolutionText->setText(QCoreApplication::translate("sunt", "Window Resolution", nullptr));
        lineEdit->setPlaceholderText(QCoreApplication::translate("sunt", "Width", nullptr));
        pxWLabel->setText(QCoreApplication::translate("sunt", "px", nullptr));
        lineEdit_2->setPlaceholderText(QCoreApplication::translate("sunt", "Height", nullptr));
        pxHLabel->setText(QCoreApplication::translate("sunt", "px", nullptr));
        playVideo1->setText(QString());
        video1Description->setText(QCoreApplication::translate("sunt", "Class Diagram - Step by Step Guide with Example", nullptr));
        playVideo2->setText(QString());
        video2Description->setText(QCoreApplication::translate("sunt", "UML Diagrams Tutorial", nullptr));
        playVideo2_2->setText(QString());
        video2Description_2->setText(QCoreApplication::translate("sunt", "Modeling Basics \342\200\223 Creating UML Class Models", nullptr));
        playVideo2_3->setText(QString());
        video2Description_3->setText(QCoreApplication::translate("sunt", "UML 2.0 Class Diagrams", nullptr));
        img1->setText(QString());
        step1->setText(QCoreApplication::translate("sunt", "1.Create your workspace", nullptr));
        img2->setText(QString());
        step2->setText(QCoreApplication::translate("sunt", "2.Select an uml element", nullptr));
        img4->setText(QString());
        step4->setText(QCoreApplication::translate("sunt", "4.Confirmation", nullptr));
        img5->setText(QString());
        step5->setText(QCoreApplication::translate("sunt", "5.Check your drawn diagram", nullptr));
        img3->setText(QString());
        step3->setText(QCoreApplication::translate("sunt", "3.Enter your data", nullptr));
        img6->setText(QString());
        step6->setText(QCoreApplication::translate("sunt", "6.Save your work", nullptr));
        img8->setText(QString());
        step8->setText(QCoreApplication::translate("sunt", "8.Start Again", nullptr));
        img7->setText(QString());
        step7->setText(QCoreApplication::translate("sunt", "7.View the generated code", nullptr));
        label->setText(QCoreApplication::translate("sunt", "Demo", nullptr));
    } // retranslateUi

};

namespace Ui {
    class sunt: public Ui_sunt {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INTERFATA_H

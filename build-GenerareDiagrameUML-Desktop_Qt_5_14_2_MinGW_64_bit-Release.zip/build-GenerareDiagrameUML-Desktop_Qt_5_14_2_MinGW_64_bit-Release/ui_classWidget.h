/********************************************************************************
** Form generated from reading UI file 'classWidget.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLASSWIDGET_H
#define UI_CLASSWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form
{
public:
    QVBoxLayout *verticalLayout;
    QFrame *topBar;
    QHBoxLayout *horizontalLayout;
    QFrame *frame_5;
    QFrame *frame_6;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *pushButton;
    QFrame *content;
    QHBoxLayout *horizontalLayout_3;
    QFrame *leftMargin;
    QFrame *continut;
    QVBoxLayout *verticalLayout_5;
    QFrame *templateDescription;
    QVBoxLayout *verticalLayout_2;
    QLabel *titleTemplate;
    QLineEdit *templateName;
    QFrame *methodAndAtributes;
    QVBoxLayout *verticalLayout_3;
    QLabel *attributeTitle;
    QTextEdit *textEdit;
    QLabel *methodsTitle;
    QTextEdit *textEdit_2;
    QFrame *submitLayout;
    QVBoxLayout *verticalLayout_4;
    QPushButton *submitButton;
    QFrame *rightMargin;
    QFrame *bottom;

    void setupUi(QWidget *Form)
    {
        if (Form->objectName().isEmpty())
            Form->setObjectName(QString::fromUtf8("Form"));
        Form->resize(400, 328);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/imagini/resources/3d-modeling (3).png"), QSize(), QIcon::Normal, QIcon::Off);
        Form->setWindowIcon(icon);
        Form->setStyleSheet(QString::fromUtf8("QWidget{\n"
"background-color: rgb(45, 45, 45);\n"
"}\n"
""));
        verticalLayout = new QVBoxLayout(Form);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        topBar = new QFrame(Form);
        topBar->setObjectName(QString::fromUtf8("topBar"));
        topBar->setMinimumSize(QSize(0, 30));
        topBar->setMaximumSize(QSize(16777215, 30));
        topBar->setStyleSheet(QString::fromUtf8("background-color : rgb(35,35,35);"));
        topBar->setFrameShape(QFrame::NoFrame);
        topBar->setFrameShadow(QFrame::Raised);
        horizontalLayout = new QHBoxLayout(topBar);
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        frame_5 = new QFrame(topBar);
        frame_5->setObjectName(QString::fromUtf8("frame_5"));
        frame_5->setMinimumSize(QSize(0, 30));
        frame_5->setMaximumSize(QSize(16777215, 30));
        frame_5->setFrameShape(QFrame::NoFrame);
        frame_5->setFrameShadow(QFrame::Raised);

        horizontalLayout->addWidget(frame_5);

        frame_6 = new QFrame(topBar);
        frame_6->setObjectName(QString::fromUtf8("frame_6"));
        frame_6->setMinimumSize(QSize(30, 30));
        frame_6->setMaximumSize(QSize(30, 30));
        frame_6->setStyleSheet(QString::fromUtf8(""));
        frame_6->setFrameShape(QFrame::NoFrame);
        frame_6->setFrameShadow(QFrame::Raised);
        horizontalLayout_2 = new QHBoxLayout(frame_6);
        horizontalLayout_2->setSpacing(0);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(frame_6);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMinimumSize(QSize(30, 30));
        pushButton->setMaximumSize(QSize(30, 30));
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180)\n"
"}"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/imagini/resources/output-onlinepngtools (5).png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton->setIcon(icon1);
        pushButton->setFlat(true);

        horizontalLayout_2->addWidget(pushButton);


        horizontalLayout->addWidget(frame_6);


        verticalLayout->addWidget(topBar);

        content = new QFrame(Form);
        content->setObjectName(QString::fromUtf8("content"));
        horizontalLayout_3 = new QHBoxLayout(content);
        horizontalLayout_3->setSpacing(0);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        leftMargin = new QFrame(content);
        leftMargin->setObjectName(QString::fromUtf8("leftMargin"));
        leftMargin->setMinimumSize(QSize(5, 0));
        leftMargin->setMaximumSize(QSize(5, 16777215));
        leftMargin->setStyleSheet(QString::fromUtf8("background-color : rgb(35,35,35);"));
        leftMargin->setFrameShape(QFrame::NoFrame);
        leftMargin->setFrameShadow(QFrame::Raised);

        horizontalLayout_3->addWidget(leftMargin);

        continut = new QFrame(content);
        continut->setObjectName(QString::fromUtf8("continut"));
        continut->setFrameShape(QFrame::NoFrame);
        verticalLayout_5 = new QVBoxLayout(continut);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        templateDescription = new QFrame(continut);
        templateDescription->setObjectName(QString::fromUtf8("templateDescription"));
        templateDescription->setFrameShape(QFrame::NoFrame);
        templateDescription->setFrameShadow(QFrame::Raised);
        verticalLayout_2 = new QVBoxLayout(templateDescription);
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        titleTemplate = new QLabel(templateDescription);
        titleTemplate->setObjectName(QString::fromUtf8("titleTemplate"));
        titleTemplate->setMinimumSize(QSize(150, 30));
        titleTemplate->setMaximumSize(QSize(150, 30));
        QFont font;
        font.setPointSize(12);
        titleTemplate->setFont(font);
        titleTemplate->setLayoutDirection(Qt::LeftToRight);
        titleTemplate->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        titleTemplate->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(titleTemplate, 0, Qt::AlignHCenter);

        templateName = new QLineEdit(templateDescription);
        templateName->setObjectName(QString::fromUtf8("templateName"));
        templateName->setMinimumSize(QSize(150, 30));
        templateName->setMaximumSize(QSize(150, 30));
        templateName->setStyleSheet(QString::fromUtf8("background-color: rgb(235, 235, 235);\n"
"border: 0px solid;\n"
"border-radius: 10px;\n"
"\n"
""));

        verticalLayout_2->addWidget(templateName);


        verticalLayout_5->addWidget(templateDescription);

        methodAndAtributes = new QFrame(continut);
        methodAndAtributes->setObjectName(QString::fromUtf8("methodAndAtributes"));
        methodAndAtributes->setFrameShape(QFrame::NoFrame);
        verticalLayout_3 = new QVBoxLayout(methodAndAtributes);
        verticalLayout_3->setSpacing(0);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        attributeTitle = new QLabel(methodAndAtributes);
        attributeTitle->setObjectName(QString::fromUtf8("attributeTitle"));
        attributeTitle->setMinimumSize(QSize(150, 30));
        attributeTitle->setMaximumSize(QSize(150, 30));
        attributeTitle->setFont(font);
        attributeTitle->setLayoutDirection(Qt::LeftToRight);
        attributeTitle->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        attributeTitle->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(attributeTitle);

        textEdit = new QTextEdit(methodAndAtributes);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setMinimumSize(QSize(150, 30));
        textEdit->setMaximumSize(QSize(150, 30));
        textEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(235, 235, 235);\n"
"border: 0px solid;\n"
"border-radius: 10px;\n"
"\n"
""));

        verticalLayout_3->addWidget(textEdit);

        methodsTitle = new QLabel(methodAndAtributes);
        methodsTitle->setObjectName(QString::fromUtf8("methodsTitle"));
        methodsTitle->setMinimumSize(QSize(150, 30));
        methodsTitle->setMaximumSize(QSize(150, 30));
        methodsTitle->setFont(font);
        methodsTitle->setLayoutDirection(Qt::LeftToRight);
        methodsTitle->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        methodsTitle->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(methodsTitle);

        textEdit_2 = new QTextEdit(methodAndAtributes);
        textEdit_2->setObjectName(QString::fromUtf8("textEdit_2"));
        textEdit_2->setMinimumSize(QSize(150, 30));
        textEdit_2->setMaximumSize(QSize(150, 30));
        textEdit_2->setStyleSheet(QString::fromUtf8("background-color: rgb(235, 235, 235);\n"
"border: 0px solid;\n"
"border-radius: 10px;\n"
"\n"
""));

        verticalLayout_3->addWidget(textEdit_2);


        verticalLayout_5->addWidget(methodAndAtributes, 0, Qt::AlignHCenter);

        submitLayout = new QFrame(continut);
        submitLayout->setObjectName(QString::fromUtf8("submitLayout"));
        submitLayout->setFrameShape(QFrame::NoFrame);
        submitLayout->setFrameShadow(QFrame::Raised);
        verticalLayout_4 = new QVBoxLayout(submitLayout);
        verticalLayout_4->setSpacing(0);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        submitButton = new QPushButton(submitLayout);
        submitButton->setObjectName(QString::fromUtf8("submitButton"));
        submitButton->setMinimumSize(QSize(100, 40));
        submitButton->setMaximumSize(QSize(100, 40));
        submitButton->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"border: 0px solid;\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(68, 68, 68);\n"
"border-radius: 15px;\n"
"}\n"
"QPushButton::hover{\n"
"background-color : rgb(48, 127, 180)\n"
"}\n"
""));
        submitButton->setFlat(true);

        verticalLayout_4->addWidget(submitButton);


        verticalLayout_5->addWidget(submitLayout, 0, Qt::AlignHCenter);


        horizontalLayout_3->addWidget(continut, 0, Qt::AlignHCenter);

        rightMargin = new QFrame(content);
        rightMargin->setObjectName(QString::fromUtf8("rightMargin"));
        rightMargin->setMinimumSize(QSize(5, 0));
        rightMargin->setMaximumSize(QSize(5, 16777215));
        rightMargin->setStyleSheet(QString::fromUtf8("background-color : rgb(35,35,35);"));
        rightMargin->setFrameShape(QFrame::NoFrame);
        rightMargin->setFrameShadow(QFrame::Raised);

        horizontalLayout_3->addWidget(rightMargin);


        verticalLayout->addWidget(content);

        bottom = new QFrame(Form);
        bottom->setObjectName(QString::fromUtf8("bottom"));
        bottom->setMinimumSize(QSize(0, 6));
        bottom->setMaximumSize(QSize(16777215, 6));
        bottom->setStyleSheet(QString::fromUtf8("background-color : rgb(35,35,35);"));
        bottom->setFrameShape(QFrame::NoFrame);

        verticalLayout->addWidget(bottom);


        retranslateUi(Form);

        QMetaObject::connectSlotsByName(Form);
    } // setupUi

    void retranslateUi(QWidget *Form)
    {
        Form->setWindowTitle(QCoreApplication::translate("Form", "Form", nullptr));
        pushButton->setText(QString());
        titleTemplate->setText(QCoreApplication::translate("Form", "Class Name", nullptr));
        templateName->setPlaceholderText(QCoreApplication::translate("Form", "Class Name", nullptr));
        attributeTitle->setText(QCoreApplication::translate("Form", "Attribute", nullptr));
        textEdit->setPlaceholderText(QCoreApplication::translate("Form", "+ example : int;", nullptr));
        methodsTitle->setText(QCoreApplication::translate("Form", "Methods", nullptr));
        textEdit_2->setPlaceholderText(QCoreApplication::translate("Form", "example() : void;", nullptr));
        submitButton->setText(QCoreApplication::translate("Form", "Ok", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Form: public Ui_Form {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLASSWIDGET_H

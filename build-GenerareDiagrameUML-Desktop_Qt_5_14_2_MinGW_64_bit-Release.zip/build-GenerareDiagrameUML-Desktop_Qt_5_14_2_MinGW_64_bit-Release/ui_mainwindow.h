/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LoadingScreen
{
public:
    QWidget *centralwidget;
    QFrame *circularProgressBarBase;
    QFrame *circularProgress;
    QFrame *circularBG;
    QFrame *container;
    QLabel *Logo;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;

    void setupUi(QMainWindow *LoadingScreen)
    {
        if (LoadingScreen->objectName().isEmpty())
            LoadingScreen->setObjectName(QString::fromUtf8("LoadingScreen"));
        LoadingScreen->resize(340, 340);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/imagini/resources/3d-modeling (3).png"), QSize(), QIcon::Normal, QIcon::Off);
        LoadingScreen->setWindowIcon(icon);
        centralwidget = new QWidget(LoadingScreen);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        circularProgressBarBase = new QFrame(centralwidget);
        circularProgressBarBase->setObjectName(QString::fromUtf8("circularProgressBarBase"));
        circularProgressBarBase->setGeometry(QRect(10, 10, 321, 320));
        circularProgressBarBase->setFrameShape(QFrame::NoFrame);
        circularProgressBarBase->setFrameShadow(QFrame::Raised);
        circularProgress = new QFrame(circularProgressBarBase);
        circularProgress->setObjectName(QString::fromUtf8("circularProgress"));
        circularProgress->setGeometry(QRect(10, 10, 300, 300));
        circularProgress->setStyleSheet(QString::fromUtf8("QFrame{\n"
"	border-radius:150px;\n"
"	background-color: qconicalgradient(cx:0.5, cy:0.5, angle:90, stop:0.749 rgba(255, 0, 127, 0), stop:0.75 rgba(85, 170, 255, 255));\n"
"}\n"
""));
        circularProgress->setFrameShape(QFrame::NoFrame);
        circularProgress->setFrameShadow(QFrame::Raised);
        circularBG = new QFrame(circularProgressBarBase);
        circularBG->setObjectName(QString::fromUtf8("circularBG"));
        circularBG->setGeometry(QRect(10, 10, 300, 300));
        circularBG->setStyleSheet(QString::fromUtf8("QFrame{\n"
"border-radius:150px;\n"
"background-color : rgba(36, 36, 36,120);\n"
"}"));
        circularBG->setFrameShape(QFrame::NoFrame);
        circularBG->setFrameShadow(QFrame::Raised);
        container = new QFrame(circularProgressBarBase);
        container->setObjectName(QString::fromUtf8("container"));
        container->setGeometry(QRect(25, 25, 270, 270));
        container->setStyleSheet(QString::fromUtf8("QFrame{\n"
"	border-radius:135px;\n"
"	background-color: rgb(36, 36, 36);\n"
"}"));
        container->setFrameShape(QFrame::NoFrame);
        container->setFrameShadow(QFrame::Raised);
        Logo = new QLabel(container);
        Logo->setObjectName(QString::fromUtf8("Logo"));
        Logo->setGeometry(QRect(70, 70, 135, 135));
        Logo->setStyleSheet(QString::fromUtf8("background-color: none;"));
        Logo->setPixmap(QPixmap(QString::fromUtf8(":/imagini/resources/3d-modeling (3).png")));
        Logo->setScaledContents(true);
        Logo->setAlignment(Qt::AlignCenter);
        label = new QLabel(container);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(80, 25, 111, 41));
        QFont font;
        font.setFamily(QString::fromUtf8("Segoe UI"));
        font.setPointSize(14);
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("background-color:none;\n"
"color : #FFFFFF\n"
""));
        label->setAlignment(Qt::AlignCenter);
        label_2 = new QLabel(container);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(120, 195, 41, 31));
        label_2->setFont(font);
        label_2->setStyleSheet(QString::fromUtf8("background-color:none;\n"
"color : #FFFFFF\n"
""));
        label_2->setAlignment(Qt::AlignCenter);
        label_3 = new QLabel(container);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(95, 230, 91, 21));
        label_3->setFont(font);
        label_3->setStyleSheet(QString::fromUtf8("QLabel{\n"
"	border-radius: 10px;\n"
"	background-color: rgb(61, 61, 61);\n"
"	color:#FFFFFF\n"
"}\n"
""));
        label_3->setAlignment(Qt::AlignCenter);
        circularBG->raise();
        circularProgress->raise();
        container->raise();
        LoadingScreen->setCentralWidget(centralwidget);

        retranslateUi(LoadingScreen);

        QMetaObject::connectSlotsByName(LoadingScreen);
    } // setupUi

    void retranslateUi(QMainWindow *LoadingScreen)
    {
        LoadingScreen->setWindowTitle(QCoreApplication::translate("LoadingScreen", "MainWindow", nullptr));
        Logo->setText(QString());
        label->setText(QCoreApplication::translate("LoadingScreen", "<html><head/><body><p><span style=\" font-size:28pt; font-weight:600; color:#ffffff;\">UML</span></p></body></html>", nullptr));
        label_2->setText(QCoreApplication::translate("LoadingScreen", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600;\">0</span><span style=\" font-size:16pt; font-weight:600; vertical-align:super;\">%</span></p></body></html>", nullptr));
        label_3->setText(QCoreApplication::translate("LoadingScreen", "<html><head/><body><p><span style=\" font-size:11pt; font-weight:600;\">loading ...</span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LoadingScreen: public Ui_LoadingScreen {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
